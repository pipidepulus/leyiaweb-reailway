import reflex as rx
from asistente_legal_constitucional_con_ia.components.sidebar import sidebar
from asistente_legal_constitucional_con_ia.components.chat import chat_area


def main_page() -> rx.Component:
    """The main UI of the application, available after login."""
    return rx.el.div(
        sidebar(),
        chat_area(),
        class_name="flex h-screen bg-gray-50 font-['Inter']",
    )