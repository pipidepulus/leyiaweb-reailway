import reflex as rx
from asistente_legal_constitucional_con_ia.pages.main_page import main_page
from asistente_legal_constitucional_con_ia.pages.login_page import login_page
from asistente_legal_constitucional_con_ia.states.auth_state import AuthState

app = rx.App(
    theme=rx.theme(appearance="light"),
    head_components=[
        rx.el.link(
            rel="preconnect",
            href="https://fonts.googleapis.com",
        ),
        rx.el.link(
            rel="preconnect",
            href="https://fonts.gstatic.com",
            crossorigin="",
        ),
        rx.el.link(
            href="https://fonts.googleapis.com/css2?family=Inter:wght@400;500;600;700;800&display=swap",
            rel="stylesheet",
        ),
    ],
)
app.add_page(login_page, route="/login")
app.add_page(
    main_page, route="/", on_load=AuthState.check_session
)