import reflex as rx
from typing import TypedDict
import os
import io
import tempfile
import json
import asyncio
from openai import OpenAI, APIError
from dotenv import load_dotenv
from asistente_legal_constitucional_con_ia.util.text_extraction import extract_text_from_bytes
from asistente_legal_constitucional_con_ia.util.scraper import (
    scrape_proyectos_recientes_camara,
)

load_dotenv()


class Message(TypedDict):
    role: str
    content: str


class FileInfo(TypedDict):
    file_id: str
    filename: str


class ChatState(rx.State):
    """Manages the chat interface, file uploads, and AI interaction."""

    messages: list[Message] = []
    thread_id: str | None = None
    file_info_list: list[FileInfo] = []
    processing: bool = False
    uploading: bool = False
    upload_progress: int = 0
    proyectos_recientes_df: str = ""
    assistant_id: str = os.getenv(
        "ASSISTANT_ID_CONSTITUCIONAL", ""
    )
    openai_api_key: str = os.getenv("OPENAI_API_KEY", "")

    @rx.var
    def has_api_keys(self) -> bool:
        return bool(
            self.assistant_id and self.openai_api_key
        )

    @rx.var
    def client(self) -> OpenAI | None:
        if self.has_api_keys:
            return OpenAI(api_key=self.openai_api_key)
        return None

    @rx.var
    def proyectos_data(self) -> list[dict]:
        if not self.proyectos_recientes_df:
            return []
        try:
            return json.loads(self.proyectos_recientes_df)
        except json.JSONDecodeError:
            return []

    @rx.event
    async def handle_upload(
        self, files: list[rx.UploadFile]
    ):
        if not files:
            yield rx.toast.error(
                "No se seleccionaron archivos."
            )
            return
        self.uploading = True
        self.upload_progress = 0
        yield
        client = self.client
        if not client:
            yield rx.toast.error(
                "Credenciales de OpenAI no configuradas."
            )
            self.uploading = False
            return
        for i, file in enumerate(files):
            try:
                upload_data = await file.read()
                extracted_text = extract_text_from_bytes(
                    upload_data, file.name
                )
                if (
                    not extracted_text
                    or not extracted_text.strip()
                ):
                    yield rx.toast.warning(
                        f"No se pudo extraer texto de '{file.name}'."
                    )
                    continue
                with tempfile.NamedTemporaryFile(
                    mode="w+",
                    delete=False,
                    suffix=".txt",
                    encoding="utf-8",
                ) as tmp_file:
                    tmp_file.write(extracted_text)
                    tmp_path = tmp_file.name
                try:
                    with open(tmp_path, "rb") as f_obj:
                        response = client.files.create(
                            file=f_obj, purpose="assistants"
                        )
                    self.file_info_list.append(
                        {
                            "file_id": response.id,
                            "filename": file.name,
                        }
                    )
                    yield rx.toast.success(
                        f"'{file.name}' procesado y subido."
                    )
                except APIError as e:
                    yield rx.toast.error(
                        f"Error al subir '{file.name}': {e.message}"
                    )
                finally:
                    os.remove(tmp_path)
            except Exception as e:
                yield rx.toast.error(
                    f"Error procesando '{file.name}': {str(e)}"
                )
            self.upload_progress = round(
                (i + 1) / len(files) * 100
            )
            yield
        self.uploading = False
        yield

    @rx.event
    def delete_file(self, file_id: str):
        client = self.client
        if not client:
            yield rx.toast.error(
                "Credenciales de OpenAI no configuradas."
            )
            return
        filename = next(
            (
                f["filename"]
                for f in self.file_info_list
                if f["file_id"] == file_id
            ),
            "archivo",
        )
        try:
            client.files.delete(file_id)
            self.file_info_list = [
                f
                for f in self.file_info_list
                if f["file_id"] != file_id
            ]
            yield rx.toast.success(
                f"'{filename}' eliminado."
            )
        except APIError as e:
            yield rx.toast.error(
                f"Error eliminando '{filename}': {e.message}"
            )

    @rx.event(background=True)
    async def scrape_proyectos(self):
        async with self:
            self.proyectos_recientes_df = ""
        df = scrape_proyectos_recientes_camara(15)
        async with self:
            if df is not None:
                self.proyectos_recientes_df = df.to_json(
                    orient="records"
                )
            else:
                self.proyectos_recientes_df = "[]"
                yield rx.toast.error(
                    "No se pudieron obtener los proyectos."
                )

    @rx.event
    def send_message(self, form_data: dict):
        user_prompt = form_data.get("prompt", "").strip()
        if not user_prompt or self.processing:
            return
        if not self.has_api_keys:
            return rx.toast.error(
                "Las credenciales de OpenAI no están configuradas en el servidor."
            )
        self.processing = True
        self.messages.append(
            {"role": "user", "content": user_prompt}
        )
        yield
        yield ChatState.generate_response

    def _get_tools(self):
        return [
            {
                "type": "function",
                "function": {
                    "name": "obtener_propuestas_recientes_congreso",
                    "description": "Obtiene títulos y números de las propuestas de ley más recientes del Congreso de Colombia.",
                    "parameters": {
                        "type": "object",
                        "properties": {},
                    },
                },
            },
            {"type": "file_search"},
        ]

    def _get_available_functions(self):
        return {
            "obtener_propuestas_recientes_congreso": lambda: json.dumps(
                {
                    "propuestas": (
                        json.loads(
                            self.proyectos_recientes_df
                        )
                        if self.proyectos_recientes_df
                        else "No data"
                    )
                }
            )
        }

    @rx.event(background=True)
    async def generate_response(self):
        client = self.client
        if not client:
            async with self:
                self.messages.append(
                    {
                        "role": "assistant",
                        "content": "Error: Cliente de OpenAI no inicializado.",
                    }
                )
                self.processing = False
            return
        try:
            async with self:
                if self.thread_id is None:
                    thread = client.beta.threads.create()
                    self.thread_id = thread.id
            attachments = [
                {
                    "file_id": fi["file_id"],
                    "tools": [{"type": "file_search"}],
                }
                for fi in self.file_info_list
            ]
            client.beta.threads.messages.create(
                thread_id=self.thread_id,
                role="user",
                content=self.messages[-1]["content"],
                attachments=attachments,
            )
            current_instructions = '\n            ## Rol Principal:\n            Eres un asistente legal ALTAMENTE ESPECIALIZADO EXCLUSIVAMENTE en derecho constitucional colombiano.\n            Tu misión es ANALIZAR CRÍTICAMENTE documentos legales (leyes o propuestas de ley) A LA LUZ de la Constitución Política de Colombia y el ordenamiento jurídico colombiano.\n            **NO RESPONDERÁS preguntas que no estén directamente relacionadas con el derecho constitucional colombiano, leyes colombianas, jurisprudencia constitucional colombiana, o el análisis de documentos legales colombianos que el usuario proporcione.**\n            \n            ## Manejo de Consultas Fuera de Especialización:\n            Si el usuario te hace una pregunta que CLARAMENTE está fuera del ámbito del derecho constitucional colombiano (ej. historia general, ciencia, otros países, etc.), DEBES declinar responderla directamente. En su lugar, responde amablemente indicando tu especialización. Por ejemplo: "Mi especialización es el derecho constitucional colombiano. ¿Tienes alguna consulta relacionada con este tema en la que pueda ayudarte?".\n            \n            ## Fuentes de Información y Metodología:\n            1.  **Archivos Adjuntos:** Si el mensaje del usuario contiene archivos adjuntos Y la consulta es sobre derecho constitucional colombiano relacionada con ellos, usa `file_search` para basar tu respuesta en ESOS archivos.\n            2.  **Base de Conocimiento Constitucional:** Para el análisis constitucional, usa tu base de conocimiento (Constitución, leyes, jurisprudencia, doctrina colombiana).\n            \n            ## Estándares para Respuestas:\n            1.  **Análisis Fundamentado:** Toda conclusión debe derivar del análisis del documento adjunto (si lo hay) y/o de tu base de conocimiento.\n            2.  **Citación Rigurosa:** Cita con precisión fuentes como Constitución (Art. Z), Ley X (Art. Y), y sentencias (ej. C-XXX/YY, T-XXX/YY, SU-XXX/YY). Usa anotaciones de `file_search` (`【1†fuente】`).\n            3.  **Formato:** Usa Markdown claro y estructurado.\n            4.  **Tono:** Profesional, experto, analítico y objetivo.\n            '
            run = client.beta.threads.runs.create(
                thread_id=self.thread_id,
                assistant_id=self.assistant_id,
                tools=self._get_tools(),
                tool_choice="auto",
                instructions=current_instructions,
            )
            while run.status in [
                "queued",
                "in_progress",
                "requires_action",
            ]:
                await asyncio.sleep(1)
                run = client.beta.threads.runs.retrieve(
                    thread_id=self.thread_id, run_id=run.id
                )
                if (
                    run.status == "requires_action"
                    and run.required_action
                ):
                    tool_calls = (
                        run.required_action.submit_tool_outputs.tool_calls
                    )
                    tool_outputs = []
                    available_functions = (
                        self._get_available_functions()
                    )
                    for tool_call in tool_calls:
                        func_name = tool_call.function.name
                        if func_name in available_functions:
                            response = available_functions[
                                func_name
                            ]()
                            tool_outputs.append(
                                {
                                    "tool_call_id": tool_call.id,
                                    "output": response,
                                }
                            )
                    if tool_outputs:
                        run = client.beta.threads.runs.submit_tool_outputs(
                            thread_id=self.thread_id,
                            run_id=run.id,
                            tool_outputs=tool_outputs,
                        )
            if run.status == "completed":
                messages_response = (
                    client.beta.threads.messages.list(
                        thread_id=self.thread_id,
                        order="desc",
                        limit=1,
                    )
                )
                assistant_message = messages_response.data[
                    0
                ]
                full_response = (
                    self._process_message_with_citations(
                        assistant_message, client
                    )
                )
                async with self:
                    self.messages.append(
                        {
                            "role": "assistant",
                            "content": full_response,
                        }
                    )
            else:
                error_msg = f"Consulta falló (Estado: {run.status})."
                async with self:
                    self.messages.append(
                        {
                            "role": "assistant",
                            "content": error_msg,
                        }
                    )
        except Exception as e:
            async with self:
                self.messages.append(
                    {
                        "role": "assistant",
                        "content": f"Error inesperado: {str(e)}",
                    }
                )
        finally:
            async with self:
                self.processing = False

    def _process_message_with_citations(
        self, message_obj, client
    ) -> str:
        message_content = message_obj.content[0].text
        annotations = message_content.annotations
        citations = []
        processed_text = message_content.value
        for index, annotation in enumerate(annotations):
            processed_text = processed_text.replace(
                annotation.text, f" [{index + 1}]"
            )
            if file_citation := getattr(
                annotation, "file_citation", None
            ):
                cited_file_id = file_citation.file_id
                file_info = next(
                    (
                        f
                        for f in self.file_info_list
                        if f["file_id"] == cited_file_id
                    ),
                    None,
                )
                filename = (
                    file_info["filename"]
                    if file_info
                    else f"Archivo ID: {cited_file_id}"
                )
                citations.append(
                    f'[{index + 1}] "{file_citation.quote}" (de {filename})'
                )
        if citations:
            return (
                processed_text
                + "\n\n**Referencias:**\n"
                + "\n".join(citations)
            )
        return processed_text