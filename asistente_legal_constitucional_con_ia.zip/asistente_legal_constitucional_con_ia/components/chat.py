import reflex as rx
from asistente_legal_constitucional_con_ia.states.chat_state import ChatState


def message_bubble(message: rx.Var[dict]) -> rx.Component:
    is_user = message["role"] == "user"
    return rx.el.div(
        rx.el.div(
            rx.markdown(
                message["content"],
                class_name="prose text-sm max-w-none",
            ),
            class_name=rx.cond(
                is_user,
                "bg-indigo-500 text-white rounded-l-xl rounded-t-xl p-3",
                "bg-gray-200 text-gray-800 rounded-r-xl rounded-t-xl p-3",
            ),
        ),
        class_name=rx.cond(
            is_user,
            "flex justify-end",
            "flex justify-start",
        ),
    )


def chat_input() -> rx.Component:
    return rx.el.form(
        rx.el.input(
            name="prompt",
            placeholder="Escribe tu consulta aquí...",
            disabled=ChatState.processing,
            class_name="flex-1 p-3 border rounded-l-lg focus:outline-none focus:ring-2 focus:ring-indigo-500",
        ),
        rx.el.button(
            rx.cond(
                ChatState.processing,
                rx.spinner(size="1"),
                rx.icon("send", size=20),
            ),
            type="submit",
            disabled=ChatState.processing,
            class_name="p-3 bg-indigo-600 text-white rounded-r-lg hover:bg-indigo-700 disabled:bg-indigo-300 flex items-center justify-center",
        ),
        on_submit=ChatState.send_message,
        reset_on_submit=True,
        class_name="flex",
    )


def chat_area() -> rx.Component:
    """The main chat interface."""
    return rx.el.main(
        rx.el.div(
            rx.cond(
                ChatState.messages.length() > 0,
                rx.el.div(
                    rx.foreach(
                        ChatState.messages, message_bubble
                    ),
                    class_name="space-y-4",
                ),
                rx.el.div(
                    rx.icon(
                        "message-square-text",
                        size=48,
                        class_name="text-gray-300",
                    ),
                    rx.el.h3(
                        "Bienvenido al Asistente Legal",
                        class_name="text-xl font-semibold text-gray-700",
                    ),
                    rx.el.p(
                        "Sube archivos, consulta propuestas o haz tu consulta en el chat.",
                        class_name="text-gray-500",
                    ),
                    class_name="flex flex-col items-center justify-center h-full text-center",
                ),
            ),
            class_name="flex-1 p-6 overflow-y-auto",
        ),
        rx.el.div(chat_input(), class_name="p-4 border-t"),
        class_name="flex-1 flex flex-col",
    )