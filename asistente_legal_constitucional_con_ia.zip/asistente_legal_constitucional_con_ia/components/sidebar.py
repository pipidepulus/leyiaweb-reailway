import reflex as rx
from asistente_legal_constitucional_con_ia.states.chat_state import ChatState
from asistente_legal_constitucional_con_ia.states.auth_state import AuthState


def file_uploader() -> rx.Component:
    return rx.el.div(
        rx.upload.root(
            rx.el.div(
                rx.icon(
                    "cloud_upload",
                    class_name="w-8 h-8 text-gray-400",
                ),
                rx.el.p("Sube archivos (PDF, DOCX, TXT)"),
                rx.el.p(
                    f"{ChatState.file_info_list.length()} / 3 archivos",
                    class_name="text-xs text-gray-500",
                ),
                class_name="flex flex-col items-center justify-center p-4 border-2 border-dashed border-gray-300 rounded-lg cursor-pointer hover:bg-gray-100",
            ),
            id="file_uploader",
            multiple=True,
            accept={
                "application/pdf": [".pdf"],
                "application/vnd.openxmlformats-officedocument.wordprocessingml.document": [
                    ".docx"
                ],
                "text/plain": [".txt"],
            },
            max_files=3,
            disabled=ChatState.uploading
            | (ChatState.file_info_list.length() >= 3),
            on_drop=ChatState.handle_upload(
                rx.upload_files(upload_id="file_uploader")
            ),
            class_name="w-full",
        ),
        rx.el.div(
            rx.foreach(
                rx.selected_files("file_uploader"),
                lambda file: rx.el.p(
                    file,
                    class_name="text-xs text-gray-600 truncate",
                ),
            ),
            class_name="mt-2 text-sm",
        ),
        rx.el.button(
            rx.cond(
                ChatState.uploading,
                rx.spinner(size="1"),
                "Procesar Archivos",
            ),
            on_click=ChatState.handle_upload(
                rx.upload_files(upload_id="file_uploader")
            ),
            disabled=ChatState.uploading,
            class_name="w-full mt-2 py-2 px-4 bg-indigo-600 hover:bg-indigo-700 text-white font-semibold rounded-md shadow-sm disabled:opacity-50 flex items-center justify-center",
        ),
        rx.cond(
            ChatState.uploading,
            rx.progress(
                value=ChatState.upload_progress,
                class_name="w-full mt-2",
            ),
        ),
        class_name="space-y-2",
    )


def file_list() -> rx.Component:
    return rx.el.div(
        rx.el.h3(
            "Archivos Disponibles",
            class_name="font-semibold text-gray-700",
        ),
        rx.cond(
            ChatState.file_info_list.length() > 0,
            rx.el.div(
                rx.foreach(
                    ChatState.file_info_list,
                    lambda file_info: rx.el.div(
                        rx.icon(
                            "file-text",
                            class_name="text-gray-500",
                        ),
                        rx.el.span(
                            file_info["filename"],
                            class_name="truncate flex-1",
                        ),
                        rx.el.button(
                            rx.icon("trash-2", size=16),
                            on_click=lambda: ChatState.delete_file(
                                file_info["file_id"]
                            ),
                            class_name="text-red-500 hover:text-red-700 p-1",
                            variant="ghost",
                        ),
                        class_name="flex items-center gap-2 p-2 bg-gray-100 rounded-md",
                    ),
                ),
                class_name="space-y-2",
            ),
            rx.el.p(
                "Sube archivos para análisis.",
                class_name="text-sm text-gray-500",
            ),
        ),
    )


def project_explorer() -> rx.Component:
    columns = [
        {"key": "Número", "title": "Número"},
        {"key": "Título", "title": "Título"},
        {"key": "Estado", "title": "Estado"},
        {
            "key": "Enlace",
            "title": "Enlace",
            "render_cell": lambda row: rx.el.a(
                rx.icon("link", size=16),
                href=row["Enlace"],
                target="_blank",
                rel="noopener noreferrer",
                class_name="text-indigo-600 hover:text-indigo-800",
            ),
        },
    ]
    return rx.el.div(
        rx.el.h3(
            "Explorar Proyectos de Ley",
            class_name="font-semibold text-gray-700",
        ),
        rx.el.p(
            "Consulta últimas propuestas (Cámara).",
            class_name="text-xs text-gray-500",
        ),
        rx.el.button(
            "Consultar Propuestas",
            on_click=ChatState.scrape_proyectos,
            class_name="w-full mt-2 py-2 px-4 bg-gray-200 hover:bg-gray-300 text-gray-800 font-semibold rounded-md shadow-sm",
        ),
        rx.cond(
            ChatState.proyectos_data.length() > 0,
            rx.el.div(
                rx.data_table(
                    data=ChatState.proyectos_data,
                    columns=columns,
                    pagination=True,
                    search=True,
                    sort=True,
                ),
                class_name="mt-4 max-h-64 overflow-y-auto",
            ),
        ),
        class_name="space-y-2",
    )


def sidebar() -> rx.Component:
    """The sidebar component for file management and other tools."""
    return rx.el.aside(
        rx.el.div(
            rx.el.h2(
                "⚖️ Asistente",
                class_name="text-xl font-bold",
            ),
            rx.el.button(
                "Cerrar Sesión",
                on_click=AuthState.logout,
                class_name="text-sm text-gray-600 hover:text-indigo-600",
            ),
            class_name="flex justify-between items-center p-4 border-b",
        ),
        rx.el.div(
            file_uploader(),
            rx.el.hr(),
            file_list(),
            rx.el.hr(),
            project_explorer(),
            class_name="p-4 space-y-6",
        ),
        class_name="w-96 bg-white border-r flex flex-col h-full",
    )